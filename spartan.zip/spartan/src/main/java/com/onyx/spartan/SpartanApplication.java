package com.onyx.spartan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpartanApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpartanApplication.class, args);
	}

}
